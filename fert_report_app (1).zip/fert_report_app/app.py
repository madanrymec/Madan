import os, datetime as dt, traceback, uuid
from flask import Flask, render_template, request, send_file, flash, redirect, url_for
import config, db, engine, report
from columns import TABLES, ZPLAN, ZMB, ZBOM

app = Flask(__name__); app.secret_key = config.SECRET_KEY
os.makedirs(config.UPLOAD_DIR, exist_ok=True); os.makedirs(config.OUTPUT_DIR, exist_ok=True)

def _save(f, tag):
    p = os.path.join(config.UPLOAD_DIR, f"{uuid.uuid4().hex[:8]}_{tag}_{os.path.basename(f.filename)}"); f.save(p); return p

@app.route("/")
def index():
    return render_template("index.html", today=dt.date.today().isoformat())

@app.route("/generate", methods=["POST"])
def generate():
    try:
        files = {k: request.files.get(k) for k in ("zplan", "zmb52", "zbomexplode")}
        if any(f is None or not f.filename for f in files.values()):
            raise ValueError("Please choose all three files: ZPLAN, ZMB52 and ZBOMEXPLODE.")
        plant = request.form.get("plant", "").strip() or "AC02"
        shop = request.form.get("shop", "").strip() or "ALL"
        pg = request.form.get("pur_group", "").strip() or "ALL"
        rdate = dt.date.fromisoformat(request.form.get("report_date") or dt.date.today().isoformat())
        dep = request.form.get("dependency") == "on"
        paths = {k: _save(f, k) for k, f in files.items()}
        dfp = db.read_sap_file(paths["zplan"], len(ZPLAN)); dfm = db.read_sap_file(paths["zmb52"], len(ZMB)); dfb = db.read_sap_file(paths["zbomexplode"], len(ZBOM))
        for name, d in (("ZPLAN", dfp), ("ZMB52", dfm), ("ZBOMEXPLODE", dfb)):
            if plant not in set(d.iloc[:, 0].astype(str).str.strip()): raise ValueError(f"Plant {plant} not found in {name}.")
        con = db.conn()
        try:
            cur = con.cursor()
            n1 = db.load_table(cur, "zplan", dfp, plant); n2 = db.load_table(cur, "zmb_stock", dfm, plant); n3 = db.load_table(cur, "zbomexplode", dfb, plant)
            con.commit()
            plan = db.read_table(cur, "zplan", plant); stock = db.read_table(cur, "zmb_stock", plant); bom = db.read_table(cur, "zbomexplode", plant)
            # --- validate what came back from MySQL before doing any work
            if len(plan) != len(dfp) or len(stock) != len(dfm) or len(bom) != len(dfb):
                raise ValueError(f"Row count after loading differs from the files (ZPLAN {len(plan)}/{len(dfp)}, "
                                 f"ZMB52 {len(stock)}/{len(dfm)}, ZBOMEXPLODE {len(bom)}/{len(dfb)}). Check the table definitions.")
            shops = sorted({str(x).strip() for x in plan["shop"].dropna()})
            if shop.upper() != "ALL":
                hit = [x for x in shops if x.upper() == shop.upper()]
                if not hit:
                    raise ValueError(f"Shop '{shop}' not found in ZPLAN for plant {plant}. Available shops: {', '.join(shops) or 'none'} (or type ALL).")
                shop = hit[0]
            plan_a, stock_a, bom_a = engine.run(plan, stock, bom, enforce_dependency=dep)
            db.write_back(cur, "zplan", plan_a, plant); db.write_back(cur, "zmb_stock", stock_a, plant)   # allocation results stored in the tables
            con.commit()
        except Exception:
            con.rollback(); raise
        finally:
            con.close()
        out = os.path.join(config.OUTPUT_DIR, f"fert_report_{plant}_{shop}_{rdate:%Y%m%d}_{uuid.uuid4().hex[:6]}.xlsx")
        stats = report.build_workbook(plan_a, stock_a, bom_a, plant, shop, pg, rdate, out)
        return render_template("index.html", today=rdate.isoformat(), done=os.path.basename(out), stats=stats, loaded=(n1, n2, n3))
    except Exception as e:
        app.logger.error(traceback.format_exc())
        flash(str(e)); return redirect(url_for("index"))

@app.route("/download/<name>")
def download(name):
    p = os.path.join(config.OUTPUT_DIR, os.path.basename(name))
    if not os.path.exists(p): return "File not found", 404
    return send_file(p, as_attachment=True, download_name="fert_report.xlsx")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
