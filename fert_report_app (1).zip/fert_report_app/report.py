"""Builds the 9 sheets of fert_report.xlsx from the allocated tables."""
import os, math, datetime as dt
import numpy as np, pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter as L
from engine import num, s_

HERE = os.path.dirname(__file__)
BLUE = PatternFill("solid", fgColor="FFA1CAF1"); SAND = PatternFill("solid", fgColor="FFFAE7B5"); DARK = PatternFill("solid", fgColor="FF2F4F4F")
MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]

def _lookup(name, key):
    p = os.path.join(HERE, "lookups", name)
    return dict(pd.read_csv(p, dtype=str, keep_default_na=False).values) if os.path.exists(p) else {}

def month_label(m):
    try:
        y, mm = str(m).replace("-", ".").split("."); return f"{MONTHS[int(mm) - 1]}-{y}"
    except Exception: return str(m)

# ------------------------------------------------------------------ row frames
def bom_frames(ba, stock, shop, pur_group, plant):
    pg_name = stock.dropna(subset=["pur_group"]).drop_duplicates("pur_group").set_index("pur_group")["pur_group_desc"].to_dict()
    mg = _lookup("mat_group_desc.csv", None)
    z = ba[(ba["plant"] == plant) & (~ba["excluded"]) & (ba["phantom"].map(s_) == "")].copy()
    z["pri4"] = z["_pri"].astype(str).str.zfill(4)
    z["pur_name"] = z["pur_group"].map(lambda x: pg_name.get(x, ""))
    z["mg_desc"] = z["mat_group"].map(lambda x: mg.get(s_(x), ""))
    z["price"] = z["unit_price"].fillna(0)
    z["req_val_bom"] = z["total_org_val"].fillna(0)
    # Assigned Value = qty x stock (moving) price from ZMB52 (falls back to BOM price when that is 0)
    mm = stock.assign(_mm=num(stock["mm_price"])).drop_duplicates("material").set_index("material")["_mm"]
    smm = z["component"].map(mm).fillna(0)
    z["asg_val"] = z["assigned"] * np.where(smm > 0, smm, z["price"])
    # Shortage Value = qty x Latest Inforecord price for brought-out items (falls back to Price)
    lp = z["latest_price"].fillna(0)
    z["short_val"] = z["shortage"] * np.where((z["comp_proc"].map(s_) == "F") & (lp > 0), lp, z["price"])
    z["mrp_val"] = z["mrp_qty"] * z["price"]
    z["_plev"] = z["_lvl"] - 1
    z = z.sort_values(["plan_week", "_pri", "_plev", "parent_code", "component", "_ord"], na_position="last")
    z["no_inforec"] = np.where(z["price_source"].map(s_) == "MM_PRICE", "NO-PRICE-LINK",
                       np.where(z["price_source"].map(s_) == "", "MISSING-VIEW", ""))
    allz = z
    sel = z[z["shop"] == shop] if shop and shop != "ALL" else z
    if pur_group and pur_group != "ALL": sel = sel[sel["pur_group"] == pur_group]
    bo = sel[(sel["comp_proc"].map(s_) == "F") & (sel["component"].map(s_) != "")]
    ih = sel[sel["comp_proc"].map(s_) != "F"]
    return allz, bo, ih

# ------------------------------------------------------------------ writer helpers
def title(ws, text, ncols, line2=None, fill=None):
    ws.cell(1, 1, text).font = Font(bold=True, size=10); ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    if line2 is not None:
        ws.cell(2, 1, line2).font = Font(bold=True, size=10); ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)

def header(ws, row, names):
    for j, h in enumerate(names, 1):
        c = ws.cell(row, j, h); c.font = Font(bold=True, size=10); c.fill = BLUE
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[L(j)].width = 17.14

def put(ws, row, values, fmts=None):
    for j, v in enumerate(values, 1):
        if isinstance(v, (float, np.floating)):
            v = None if math.isnan(v) else float(v)
        c = ws.cell(row, j, v)
        if fmts and fmts.get(j) and isinstance(v, (int, float)): c.number_format = fmts[j]

Q3, Q2 = "0.000", "0.00"

# ------------------------------------------------------------------ sheets
def sheet_missing_view(wb, allz, d):
    ws = wb.create_sheet("MISSING VIEW"); hd = ["Srl.", " PLANT", "Component", "Component Desc", "Material Group", "Mat.Grp.Desc", "Pur.group", "Name"]
    title(ws, f"Missing MRP / Purchase views as on date -{d}", len(hd)); header(ws, 2, hd)
    x = allz[(allz["no_inforec"] == "MISSING-VIEW") & (allz["comp_proc"].map(s_) == "F") & (allz["component"].map(s_) != "")].drop_duplicates("component").sort_values("component")
    for i, r in enumerate(x.itertuples(), 1):
        put(ws, 2 + i, [i, r.plant, r.component, r.mat_desc, r.mat_group, r.mg_desc, r.pur_group, r.pur_name])

def sheet_plan(wb, plan, shop, plant, d):
    ws = wb.create_sheet("PLAN"); pr = _lookup("product_desc.csv", None)
    p = plan[(plan["plant"] == plant)]
    if shop and shop != "ALL": p = p[p["shop"] == shop]
    p = p.assign(pri_n=num(p["priority"]).fillna(0).astype(int)).sort_values(["plan_week", "pri_n"], kind="stable")
    title(ws, f"Plan as on date -{d}", 15, "Plan for: ALL")
    row = 3
    for sec, h5, h6 in (("FERT", " FERT", "FERT Desc"), ("SPARE", "SPARE", "SPARE Desc")):
        header(ws, row, ["Srl.", " PLANT", "Product", "Product Desc", h5, h6, "Plan Week", "Plan Month", "Del Date", "Priority", "Plan Qty", "Plan Val", "Assigned Qty", "Assigned Value", "Remark"])
        x = p[p["fert_or_spare"].map(s_).str.upper() == sec]
        for i, r in enumerate(x.itertuples(), 1):
            row += 1
            put(ws, row, [i, r.plant, r.product, pr.get(s_(r.product), ""), r.material, r.material_desc, r.plan_week, r.plan_month, r.req_deliv_date,
                          str(r.pri_n).zfill(4), r.plan_qty, r.plan_value, r.assigned_fg_qty, r.fg_assigned_value, ""], {11: Q2, 12: Q2, 13: Q2, 14: Q2})
        row += 3
    return p

def alloc_sheet(wb, name, df, d, pg, tail):
    cols = ["Srl.", " PLANT", "Product", " FERT", "FERT Desc", "Plan Week", "Plan Month", "Del Date", "Priority", "Plan Qty", "Parent Code", "Parent Desc",
            "SA Required Qty", "Component", "Component Desc", "Material Group", "Mat.Grp.Desc", "UOM", "Price", "Pur.Group", "Pur.Name", "Proc.Typ", "Spl.Proc.Typ", "ABC Class"]
    return cols

def common(r):
    return [r.plant, r.product, r.fert, r.fert_desc, r.plan_week, r.plan_month, r.req_deliv_date, r.pri4, r.plan_qty, r.parent_code, r.parent_desc,
            r.sa_required, r.component if s_(r.component) else "", r.mat_desc, r.mat_group, r.mg_desc, r.uom, r.price, r.pur_group, r.pur_name, r.comp_proc, r.comp_spl, r.abc]

def sheet_shortage(wb, bo, d, pg):
    hd = ["Srl.", " PLANT", "PRODUCT", " FERT", "FERT Desc", "Plan Week", "Plan Month", "Del Date", "Priority", "Plan Qty", "Parent Code", "Parent Desc", "SA Required Qty",
          "Component", "Component Desc", "Material Group", "Mat.Grp.Desc", "UOM", "Price", "Pur.Group", "Pur.Name", "Proc.Typ", "Spl.Proc.Typ", "ABC Class",
          "Required Qty", "Required Val", "Assigned Qty", "Assigned Value", "Shortage Qty", "Shortage Value", "Price Source", "NO InfoRecord"]
    ws = wb.create_sheet("SHORTAGE LIST"); title(ws, f"Material Shortage as on date -{d}", len(hd), f"Purchase group: {pg}"); header(ws, 3, hd)
    x = bo[bo["shortage"] > 1e-9]
    f = {10: Q2, 13: Q3, 19: Q2, 25: Q3, 26: Q2, 27: Q3, 28: Q2, 29: Q3, 30: Q2}
    for i, r in enumerate(x.itertuples(), 1):
        put(ws, 3 + i, [i] + common(r) + [r.total_org_qty, r.req_val_bom, r.assigned, r.asg_val, r.shortage, r.short_val, r.price_source, r.no_inforec], f)

def sheet_bo(wb, bo, d, pg):
    hd = ["Srl.", " PLANT", "Product", " FERT", "FERT Desc", "Plan Week", "Plan Month", "Del Date", "Priority", "Plan Qty", "Parent Code", "Parent Desc", "SA Required Qty",
          "Component", "Component Desc", "Material Group", "Mat.Grp.Desc", "UOM", "Price", "Pur.Group", "Pur.Name", "Proc.Typ", "Spl.Proc.Typ", "ABC Class",
          "Req.Qty as per BOM", "Req.Val as per BOM", "Req.Qty as per MRP", "Req.Val as per MRP", "Assigned Qty", "Assigned Value", "Shortage Qty", "Shortage Value",
          "Price Source", "Latest Price", "NO InfoRecord"]
    ws = wb.create_sheet("STOCK ALLOCATION-Brought Out"); title(ws, f"Material Stock Allocation as on date -{d}", len(hd), f"Purchase group: {pg}"); header(ws, 3, hd)
    f = {10: Q2, 13: Q3, 19: Q2, 25: Q3, 26: Q2, 27: Q3, 28: Q2, 29: Q3, 30: Q2, 31: Q3, 32: Q2, 34: Q2}
    for i, r in enumerate(bo.itertuples(), 1):
        put(ws, 3 + i, [i] + common(r) + [r.total_org_qty, r.req_val_bom, r.mrp_qty, r.mrp_val, r.assigned, r.asg_val, r.shortage, r.short_val, r.price_source, r.latest_price, r.no_inforec], f)

def sheet_ih(wb, ih, d, pg):
    hd = ["Srl.", " PLANT", "Product", " FERT", "FERT Desc", "Plan Week", "Plan Month", "Del Date", "Priority", "Plan Qty", "Parent Code", "Parent Desc", "SA Required Qty",
          "Component", "Component Desc", "Material Group", "Mat.Grp.Desc", "UOM", "Price", "Pur.Group", "Pur.Name", "Proc.Typ", "Spl.Proc.Typ", "ABC Class",
          "Req.Qty as per BOM", "Req.Val as per BOM", "Req.Qty as per MRP", "Req.Val as per MRP", "Assigned Qty", "Assigned Value", "Shortage Qty", "Shortage Value", "Routing Group"]
    ws = wb.create_sheet("STOCK ALLOCATION- In house"); title(ws, f"Material Stock Allocation as on date -{d}", len(hd), f"Purchase group: {pg}"); header(ws, 3, hd)
    f = {10: Q2, 13: Q3, 19: Q2, 25: Q3, 26: Q2, 27: Q3, 28: Q2, 29: Q3, 30: Q2, 31: Q3, 32: Q2}
    for i, r in enumerate(ih.itertuples(), 1):
        desc = r.mat_desc if s_(r.component) else r.mat_desc
        put(ws, 3 + i, [i] + common(r) + [r.total_org_qty, r.req_val_bom, r.mrp_qty, r.mrp_val, r.assigned, r.asg_val, r.shortage, r.short_val, ""], f)

def usable_frame(stock, plan_s, bo, ih, plant):
    s = stock[stock["plant"] == plant].copy()
    for c in ["total_orig_qty", "total_orig_val"]: s[c] = num(s[c])
    g = {}
    for df, mc, qc, vc in ((bo, "component", "assigned", "asg_val"), (ih, "component", "assigned", "asg_val")):
        for m, q, v in zip(df[mc], df[qc], df[vc]): a = g.setdefault(s_(m), [0.0, 0.0]); a[0] += q; a[1] += v
    for m, q, v in zip(plan_s["material"], plan_s["assigned_fg_qty"], plan_s["fg_assigned_value"]):
        a = g.setdefault(s_(m), [0.0, 0.0]); a[0] += q; a[1] += v
    seen = set(); uq, uv = [], []
    for m in s["material"]:
        m = s_(m)
        if m in seen or m not in g: uq.append(0.0); uv.append(0.0)
        else: uq.append(g[m][0]); uv.append(g[m][1]); seen.add(m)
    s["usable_qty"] = uq; s["usable_val"] = uv
    s["unusable_qty"] = s["total_orig_qty"] - s["usable_qty"]; s["unusable_val"] = s["total_orig_val"] - s["usable_val"]
    return s

def sheet_usable(wb, u, d, shop):
    mg = _lookup("mat_group_desc.csv", None)
    hd = ["Srl.", " PLANT", " Material", "Material Type", "Material Desc", "Material Group", "Mat.Grp.Desc", "UOM", "Pur.Group", "Pur.Name", "Proc.Typ", "Spl.Proc.Typ", "ABC Class",
          "Total Qty", "Total Val", "Usable Qty", "Usable Value", "Unusable Qty", "Unusable Value"]
    ws = wb.create_sheet("USABLE &  UNUSABLE STOCK"); title(ws, f"Unusable Stock as on date -{d}", len(hd), "Plan for: ALL"); header(ws, 3, hd)
    f = {14: Q3, 15: Q2, 16: Q3, 17: Q2, 18: Q3, 19: Q2}
    for i, r in enumerate(u.itertuples(), 1):
        put(ws, 3 + i, [i, r.plant, r.material, r.material_type, r.material_desc, r.material_group, mg.get(s_(r.material_group), ""), r.uom, r.pur_group, r.pur_group_desc,
                        r.proc_type, r.spl_proc, r.abc, r.total_orig_qty, r.total_orig_val, r.usable_qty, r.usable_val, r.unusable_qty, r.unusable_val], f)

def moq_frame(allz, u):
    z = allz[(allz["comp_proc"].map(s_) == "F") & (allz["component"].map(s_) != "") & (allz["min_lot"].fillna(0) > 0)]
    if z.empty: return z
    g = z.groupby("component", sort=True).agg(mat_desc=("mat_desc", "first"), mat_group=("mat_group", "first"), uom=("uom", "first"), pur_group=("pur_group", "first"),
        pur_name=("pur_name", "first"), comp_proc=("comp_proc", "first"), comp_spl=("comp_spl", "first"), abc=("abc", "first"), moq=("min_lot", "first"),
        price=("price", "first"), rop=("reorder_point", "first"), short=("shortage", "sum"), assigned=("assigned", "sum")).reset_index()
    st = u.groupby("material").agg(q=("total_orig_qty", "sum"), v=("total_orig_val", "sum"))
    g["stock_q"] = g["component"].map(st["q"]).fillna(0); g["stock_v"] = g["component"].map(st["v"]).fillna(0)
    free = (g["stock_q"] - g["assigned"]).clip(lower=0)
    # APPROXIMATION of the SAP MRP lot-sizing result: net need = shortage + shortfall to reorder point, rounded up to MOQ multiples
    net = g["short"] + (g["rop"].fillna(0) - free).clip(lower=0)
    g["mrp_q"] = np.where(net > 1e-9, np.ceil(net / g["moq"]) * g["moq"], 0.0)
    g["add_q"] = (g["mrp_q"] - g["short"]).clip(lower=0)
    return g

def sheet_moq(wb, g, d, pg, plant):
    hd = ["Srl.", " PLANT", "Component", "Component Desc", "Material Group", "UOM", "Pur.Group", "Pur.Name", "Proc.Typ", "Spl.Proc.Typ", "ABC Class", "MOQ Qty", "Unit Price",
          "Total Stock Qty", "Total Stock Val", "Shortage Qty as per BOM", "Shortage Val as per BOM", "As Per MRP Qty", "As Per MRP Val", "Addtional MOQ Qty", "Addtional MOQ Val"]
    ws = wb.create_sheet("MOQ VAL"); title(ws, f"LIST OF ITEMS WITH MOQ QTY AS ON DATE -{d}", len(hd), f"Purchase group: {pg}"); header(ws, 3, hd)
    f = {12: Q3, 13: Q2, 14: Q3, 15: Q2, 16: Q3, 17: Q2, 18: Q3, 19: Q2, 20: Q3, 21: Q2}
    for i, r in enumerate(g.itertuples(), 1):
        put(ws, 3 + i, [i, plant, r.component, r.mat_desc, r.mat_group, r.uom, r.pur_group, r.pur_name, r.comp_proc, r.comp_spl, r.abc, r.moq, r.price, r.stock_q, r.stock_v,
                        r.short, r.short * r.price, r.mrp_q, r.mrp_q * r.price, r.add_q, r.add_q * r.price], f)

def sheet_npl(wb, allz, d, pg, plant):
    hd = ["Srl.", " PLANT", "Component", "Component Desc", "Material Group", "UOM", "Pur.Group", "Pur.Name", "Proc.Typ", "Spl.Proc.Typ", "ABC Class", "Tot BOM Qty", "Tot PR Qty", "INFOREC Price"]
    ws = wb.create_sheet("NO PRICE LINK"); title(ws, f"LIST OF ITEMS WITHOUT INFORECORD AS ON DATE -{d}", len(hd), f"Purchase group: {pg}"); header(ws, 3, hd)
    z = allz[(allz["no_inforec"] == "NO-PRICE-LINK") & (allz["comp_proc"].map(s_) == "F")]
    if pg != "ALL": z = z[z["pur_group"] == pg]
    g = z.groupby("component", sort=True).agg(mat_desc=("mat_desc", "first"), mat_group=("mat_group", "first"), uom=("uom", "first"), pur_group=("pur_group", "first"),
        pur_name=("pur_name", "first"), comp_proc=("comp_proc", "first"), comp_spl=("comp_spl", "first"), abc=("abc", "first"), b=("total_org_qty", "sum"), p=("mrp_qty", "sum")).reset_index()
    g = g[g["p"] > 1e-9]
    for i, r in enumerate(g.itertuples(), 1):
        put(ws, 3 + i, [i, plant, r.component, r.mat_desc, r.mat_group, r.uom, r.pur_group, r.pur_name, r.comp_proc, r.comp_spl, r.abc, r.b, r.p, ""], {12: Q3, 13: Q3})

def sheet_summary(wb, plan_s, bo, ih, u, moq, d, plant, shop):
    ws = wb.create_sheet("Summary"); LK = 1e5
    months = sorted({s_(m) for m in plan_s["plan_month"] if s_(m)}); labels = [month_label(m) for m in months]; n = len(months)
    ws.column_dimensions["A"].width = 38.14
    for j in range(2, n + 3): ws.column_dimensions[L(j)].width = 13
    ws.cell(1, 1, f"FUNDING PLAN AS ON DATE -{d}-{plant}-{shop}").font = Font(bold=True, color="FFFFFFFF")
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=2)
    ws.cell(1, 3, "MONTHWISE SUMMARY").font = Font(bold=True, color="FFFFFFFF")
    if n > 1: ws.merge_cells(start_row=1, start_column=3, end_row=1, end_column=n + 2)
    for j in range(1, n + 3): ws.cell(1, j).fill = DARK; ws.cell(1, j).alignment = Alignment(horizontal="center")
    for j, h in enumerate(["Sales Plan for the  Plant:", "TOTAL"] + labels, 1):
        c = ws.cell(2, j, h); c.font = Font(bold=True); c.fill = SAND; c.alignment = Alignment(horizontal="center")
    def bymonth(df, mcol, vcol, scale=LK):
        g = df.groupby(df[mcol].map(s_))[vcol].sum(); return [float(g.get(m, 0.0)) / scale for m in months]
    fert = plan_s[plan_s["fert_or_spare"].map(s_).str.upper() == "FERT"]; spare = plan_s[plan_s["fert_or_spare"].map(s_).str.upper() == "SPARE"]
    f_used = u[u["proc_type"].map(s_) == "F"]
    tot_stock, tot_used = u["total_orig_val"].sum() / LK, u["usable_val"].sum() / LK
    proc_used, proc_unused = f_used["usable_val"].sum() / LK, f_used["unusable_val"].sum() / LK
    add_moq = float((moq["add_q"] * moq["price"]).sum() / LK) if len(moq) else 0.0
    rows = {3: ("Sales Plan Qty", fert["plan_qty"].sum(), bymonth(fert, "plan_month", "plan_qty", 1)),
            4: ("Sales Plan Value", fert["plan_value"].sum() / LK, bymonth(fert, "plan_month", "plan_value")),
            6: ("Spare Plan Qty", spare["plan_qty"].sum(), bymonth(spare, "plan_month", "plan_qty", 1)),
            7: ("Spare Plan Value", spare["plan_value"].sum() / LK, bymonth(spare, "plan_month", "plan_value")),
            9: ("Total Bom Requirement Value", None, None),
            10: ("        Brought out Materials-as per BOM", bo["req_val_bom"].sum() / LK, bymonth(bo, "plan_month", "req_val_bom")),
            11: ("        Brought out Materials-as per MRP", bo["mrp_val"].sum() / LK, bymonth(bo, "plan_month", "mrp_val")),
            12: ("        Addtional MOQ Value-as per MRP", add_moq, None),
            14: ("Total Stock Value", tot_stock, None),
            15: ("Total Value of Stock used for current plan", tot_used, None),
            16: ("        Procured -Value of Stock used for Current Plan", proc_used, bymonth(bo, "plan_month", "asg_val")),
            17: ("        Inhouse  - Value of Stock used for Current Plan", tot_used - proc_used, bymonth(ih, "plan_month", "asg_val")),
            18: ("Total Value of Stock not used for current plan", tot_stock - tot_used, None),
            19: ("        Procured -Value of Stock not used for Current Plan", proc_unused, None),
            20: ("        Inhouse  - Value of Stock not used for Current Plan", tot_stock - tot_used - proc_unused, None),
            22: ("Total Shortage Value", bo["short_val"].sum() / LK, bymonth(bo, "plan_month", "short_val"))}
    for r, (lab, tot, mv) in rows.items():
        ws.cell(r, 1, lab).font = Font(bold=True); ws.cell(r, 1).fill = BLUE
        if tot is not None: c = ws.cell(r, 2, float(tot)); c.number_format = Q2; c.fill = BLUE; c.font = Font(bold=True)
        else: ws.cell(r, 2).fill = BLUE
        for j in range(n):
            c = ws.cell(r, 3 + j, None if mv is None else float(mv[j])); c.fill = BLUE
            if mv is not None: c.number_format = Q2

def build_workbook(plan, stock, ba, plant, shop, pur_group, report_date, path):
    d = report_date.strftime("%d/%m/%Y"); pg = pur_group or "ALL"
    stock_u = stock.copy()
    allz, bo, ih = bom_frames(ba, stock, shop, pg, plant)
    wb = Workbook(); wb.remove(wb.active)
    sheet_missing_view(wb, allz, d)
    plan_s = sheet_plan(wb, plan, shop, plant, d)
    sheet_shortage(wb, bo, d, pg); sheet_bo(wb, bo, d, pg); sheet_ih(wb, ih, d, pg)
    u = usable_frame(stock, plan_s, bo, ih, plant); sheet_usable(wb, u, d, shop)
    moq = moq_frame(allz[allz["shop"] == shop] if False else allz, u)
    sheet_moq(wb, moq, d, pg, plant); sheet_npl(wb, allz, d, pg, plant)
    sheet_summary(wb, plan_s, bo, ih, u, moq, d, plant, shop)
    # report order identical to fert_report.xlsx
    wb.save(path)
    return dict(plan=len(plan_s), shortage=int((bo["shortage"] > 1e-9).sum()), brought_out=len(bo), in_house=len(ih), stock=len(u), moq=len(moq))
