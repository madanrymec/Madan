# FERT report (Flask + PyMySQL)
1. `mysql < schema.sql` (your 3 tables, unchanged) then `mysql < schema_fix.sql` (3-decimal quantity columns) -- or set `AUTO_WIDEN_COLUMNS=1`.
2. `pip install -r requirements.txt`; set DB_HOST / DB_USER / DB_PASSWORD / DB_NAME env vars (config.py).
3. `python app.py` -> http://localhost:5000, upload ZPLAN, ZMB52, ZBOMEXPLODE, choose plant / shop (SH-3) / purchase group, download fert_report.xlsx.

Files: columns.py (positional column maps), db.py (load/read/write with type checks), engine.py (allocation), report.py (9 sheets), app.py, templates/index.html, lookups/*.csv (material-group & product descriptions taken from your fert_report.xlsx; not in the 3 SAP tables).
Allocation order: plan week, then priority, all shops together; stock is plant-wide. Results are written back into zplan (FG columns) and zmb_stock (assigned/balance).
