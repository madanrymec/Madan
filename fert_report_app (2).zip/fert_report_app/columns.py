"""Positional column maps.  The Excel exports and the MySQL tables have the same
column ORDER, so every file is read by position and renamed to clean names here."""

ZPLAN = ["plant","material","plan_week","plan_month","priority","sales_doc","item_sd","vendor_code",
 "customer","name1","order_finish_date","req_deliv_date","plan_quantity","material_desc","plan_value",
 "plan_qty","orig_plan_value","frame","rating_kw","user_priority","orig_fg_stock","assigned_fg_qty",
 "fg_stock_after","balance_plan_qty","shop","vendor_name","fert_or_spare","product","check_bom",
 "mm_price","fg_assigned_value","mc_serials","profit_center","stock_from_vendor"]

ZMB = ["plant","material","vendor_code","sales_doc","item_sd","material_type","material_desc",
 "material_group","uom","storage_loc","unrestricted","in_qi","total_orig_qty","total_value","total_val",
 "total_orig_val","balance_qty","balance_val","abc","proc_type","spl_proc","vendor_name","pur_group",
 "pur_group_desc","assigned_qty","assigned_val","mm_price","blocked","blocked_val","planning_strategy"]

ZBOM = ["plant","plan_week","plan_month","priority","sales_doc","item_sd","vendor_code","fert",
 "sub_assembly","path","path_pred","component","serial","level","bom","item_sd1","fert_desc",
 "parent_desc","parent_mat_group","parent_proc","parent_spl","bom_qty","plan_qty","total_bom_qty",
 "comp_proc","comp_spl","mat_group","mat_desc","uom","phantom","abc","total_bom_val","parent_code",
 "parent_desc2","parent_mat_group2","dep1","dep2","unit_price","shop","bulk","pur_group","planner",
 "price_source","info_type","customer","name1","order_finish_date","req_deliv_date","vendor_name",
 "sa_qty","pur_val_key","product","total_org_qty","total_org_val","mm_price","mc_serials","min_lot",
 "rounding","reorder_point","profit_center","latest_price","planning_strategy"]

assert (len(ZPLAN), len(ZMB), len(ZBOM)) == (34, 30, 62)
TABLES = {"zplan": ZPLAN, "zmb_stock": ZMB, "zbomexplode": ZBOM}
