import sys; import os; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import pandas as pd, numpy as np
from columns import *; import engine

def plan_df(lines):
    rows=[]
    for (fert,week,month,pri,qty,shop) in lines:
        r={c:None for c in ZPLAN}; r.update(plant='AC02',material=fert,plan_week=week,plan_month=month,priority=str(pri),plan_qty=qty,mm_price=100.0,shop=shop,fert_or_spare='FERT')
        rows.append(r)
    return pd.DataFrame(rows)[ZPLAN]
def stock_df(items):
    rows=[]
    for (mat,typ,qty) in items:
        r={c:None for c in ZMB}; r.update(plant='AC02',material=mat,material_type=typ,total_orig_qty=qty,total_orig_val=qty*100.0,mm_price=100.0,pur_group='300'); rows.append(r)
    return pd.DataFrame(rows)[ZMB]
def bom_df(lines):
    """for every plan line: AA101 -> FA(E) -> GA(E) -> C1(F, 1 per GA) and FA -> C2(F, 2 per FA)"""
    rows=[]; ser=0
    for (fert,week,month,pri,qty,shop) in lines:
        def add(level,parent,comp,proc,bomq,total):
            nonlocal ser; ser+=1
            r={c:None for c in ZBOM}; r.update(plant='AC02',plan_week=week,plan_month=month,priority=pri,fert=fert,serial=ser,level=level,parent_code=parent,component=comp,
                comp_proc=proc,bom_qty=bomq,plan_qty=qty,total_bom_qty=total,total_org_qty=total,total_org_val=total*100.0,unit_price=100.0,shop=shop,price_source='STOCK_VAL',pur_val_key='1',
                mat_desc=comp,parent_proc='E' if parent!=fert else None)
            rows.append(r)
        add(1,fert,'FA','E',1,qty); add(2,'FA','GA','E',1,qty); add(3,'GA','C1','F',1,qty); add(2,'FA','C2','F',2,2*qty)
    return pd.DataFrame(rows)[ZBOM]
def show(title,lines,stock,expect):
    p,b=plan_df(lines),bom_df(lines); s=stock_df(stock)
    pa,sa,ba=engine.run(p,s,b,enforce_dependency=False)
    print('\n'+title)
    print(pa[['plan_week','priority','plan_qty','orig_fg_stock','assigned_fg_qty','balance_plan_qty']].to_string(index=False))
    t=ba[['plan_week','priority','component','total_org_qty','req_after_fg_sa','assigned','shortage']]
    print(t.to_string(index=False))
    ok=True
    for k,v in expect.items():
        wk,pri,comp,col=k; x=t[(t.plan_week==wk)&(t.priority==pri)&(t.component==comp)][col].iloc[0]
        flag=abs(x-v)<1e-9; ok&=flag
        if not flag: print('   MISMATCH',k,'got',x,'expected',v)
    print('   RESULT:','PASS' if ok else 'FAIL'); return ok

L=[('AA101','2026-01','2026.01',1,3,'SH-3'),('AA101','2026-03','2026.01',2,7,'SH-3')]
r=[]
# Document scenario: FERT stock 3 (=week-1 plan), FA stock 3 -> FA must NOT be given to week-1 (no balance), goes to week-3; below FA reduced; GA & C1 required only for the rest
r.append(show('1) FERT stock 3, FA stock 3 (document example)',L,[('AA101','FERT',3),('FA','HALB',3)],
  {('2026-01',1,'FA','req_after_fg_sa'):0.0,('2026-01',1,'C1','req_after_fg_sa'):0.0,
   ('2026-03',2,'FA','assigned'):3.0,('2026-03',2,'GA','req_after_fg_sa'):4.0,('2026-03',2,'C1','req_after_fg_sa'):4.0,('2026-03',2,'C2','req_after_fg_sa'):8.0}))
# FA stock covers everything of week 3 (stock 7): GA and components need nothing
r.append(show('2) FA stock >= requirement: nothing below FA is required',[('AA101','2026-03','2026.01',2,7,'SH-3')],[('FA','HALB',9)],
  {('2026-03',2,'FA','assigned'):7.0,('2026-03',2,'GA','req_after_fg_sa'):0.0,('2026-03',2,'C1','req_after_fg_sa'):0.0,('2026-03',2,'C2','req_after_fg_sa'):0.0,('2026-03',2,'C1','assigned'):0.0}))
# GA stock only: FA is looked at first (no stock), GA from stock reduces its component C1, but C2 (directly under FA) is still required
r.append(show('3) Only GA available: GA components not required, FA-level component still required',[('AA101','2026-03','2026.01',2,7,'SH-3')],[('GA','HALB',5),('C1','ROH',100),('C2','ROH',100)],
  {('2026-03',2,'FA','assigned'):0.0,('2026-03',2,'GA','assigned'):5.0,('2026-03',2,'C1','req_after_fg_sa'):2.0,('2026-03',2,'C1','assigned'):2.0,('2026-03',2,'C2','req_after_fg_sa'):14.0,('2026-03',2,'C2','assigned'):14.0}))
# Priority: same week, priority 1 must get the scarce FA stock before priority 2
L2=[('AA101','2026-05','2026.01',2,4,'SH-3'),('AA101','2026-05','2026.01',1,4,'SH-3')]
r.append(show('4) Priority: same week, priority 1 is served before priority 2 (FA stock 5)',L2,[('FA','HALB',5)],
  {('2026-05',1,'FA','assigned'):4.0,('2026-05',2,'FA','assigned'):1.0,('2026-05',1,'C1','req_after_fg_sa'):0.0,('2026-05',2,'C1','req_after_fg_sa'):3.0}))
# Month / week order: earlier week first even if listed later; month first
L3=[('AA101','2026-12','2026.03',1,2,'SH-3'),('AA101','2026-04','2026.01',9,2,'SH-3')]
r.append(show('5) Month / week order beats priority number (FA stock 2)',L3,[('FA','HALB',2)],
  {('2026-04',9,'FA','assigned'):2.0,('2026-12',1,'FA','assigned'):0.0}))
# Shop sequence: SH-3 first then SH-5 from left-over
L4=[('AA101','2026-01','2026.01',1,3,'SH-5'),('AA101','2026-09','2026.02',1,3,'SH-3')]
r.append(show('6) Shop sequence: SH-3 allocated first (FA stock 4), SH-5 gets the left-over',L4,[('FA','HALB',4)],
  {('2026-09',1,'FA','assigned'):3.0,('2026-01',1,'FA','assigned'):1.0}))
print('\nALL PASS' if all(r) else '\nSOME FAILED')
