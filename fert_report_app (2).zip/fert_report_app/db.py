import re, datetime as dt
import numpy as np, pandas as pd, pymysql
from config import DB, AUTO_WIDEN_COLUMNS
from columns import TABLES

def conn():
    return pymysql.connect(**DB, cursorclass=pymysql.cursors.Cursor, autocommit=False)

def table_columns(cur, table):
    cur.execute(f"SHOW COLUMNS FROM `{table}`")
    return [(r[0], r[1].lower()) for r in cur.fetchall()]   # (name, type) in table order

def read_sap_file(path, ncols):
    """SAP exports named .xls are often real .xlsx files -> sniff the content."""
    with open(path, "rb") as f:
        head = f.read(4)
    engine = "openpyxl" if head[:2] == b"PK" else "xlrd"
    df = pd.read_excel(path, dtype=object, header=0, engine=engine)
    if df.shape[1] < ncols:
        raise ValueError(f"{path}: expected {ncols} columns, found {df.shape[1]}")
    return df.iloc[:, :ncols]

def _clean(v):
    if v is None or (isinstance(v, float) and np.isnan(v)) or v is pd.NaT: return None
    if isinstance(v, str):
        v = v.strip()
        return v if v != "" else None
    return v

def _to_num(v):
    v = _clean(v)
    if v is None: return None
    if isinstance(v, str): v = v.replace(",", "").strip()
    try: return float(v)
    except Exception: return None

def prepare_rows(df, cols_meta, table):
    """Convert a dataframe to python values matching the MySQL column types. Returns (rows, issues)."""
    issues, rows_cols = {}, []
    for i, (name, typ) in enumerate(cols_meta):
        s = df.iloc[:, i]
        m = re.match(r"(decimal|numeric)\((\d+),(\d+)\)", typ)
        if m:
            p, sc = int(m.group(2)), int(m.group(3))
            vals = [_to_num(x) for x in s]
            for x in vals:
                if x is None: continue
                if abs(x) >= 10 ** (p - sc):
                    issues.setdefault(name, set()).add(("range", p, sc)); break
            if any(x is not None and abs(round(x, 6) - round(x, sc)) > 1e-9 for x in vals):
                issues.setdefault(name, set()).add(("scale", p, sc))
            rows_cols.append(vals)
        elif typ.startswith(("int", "bigint", "smallint", "tinyint")):
            rows_cols.append([None if _to_num(x) is None else int(round(_to_num(x))) for x in s])
        elif typ.startswith("date"):
            out = []
            for x in s:
                x = _clean(x)
                if x is None: out.append(None); continue
                t = pd.to_datetime(x, dayfirst=True, errors="coerce")
                out.append(None if pd.isna(t) else t.date())
            rows_cols.append(out)
        else:
            m = re.match(r"varchar\((\d+)\)", typ); n = int(m.group(1)) if m else 10**9
            out = []
            for x in s:
                x = _clean(x)
                if x is not None:
                    if isinstance(x, float) and x.is_integer(): x = int(x)
                    x = str(x)
                    if len(x) > n: issues.setdefault(name, set()).add(("length", len(x), n))
                out.append(x)
            rows_cols.append(out)
    return list(zip(*rows_cols)), issues

def widen_sql(table, issues):
    stmts = []
    for name, s in issues.items():
        for kind, a, b in s:
            if kind in ("range", "scale"):
                stmts.append(f"ALTER TABLE `{table}` MODIFY `{name}` DECIMAL(18,4) DEFAULT NULL;")
            elif kind == "length":
                stmts.append(f"ALTER TABLE `{table}` MODIFY `{name}` VARCHAR({max(a, b) + 50}) DEFAULT NULL;")
    return sorted(set(stmts))

def load_table(cur, table, df, plant):
    meta = table_columns(cur, table)
    if len(meta) != len(TABLES[table]):
        raise ValueError(f"table {table} has {len(meta)} columns, expected {len(TABLES[table])}")
    rows, issues = prepare_rows(df, meta, table)
    if issues:
        sql = widen_sql(table, issues)
        if not AUTO_WIDEN_COLUMNS:
            raise ValueError(f"Table `{table}` has columns too small for the SAP data "
                             f"({', '.join(issues)}). Run these statements (or set AUTO_WIDEN_COLUMNS=1):\n" + "\n".join(sql))
        for q in sql: cur.execute(q)
        meta = table_columns(cur, table)
        rows, issues = prepare_rows(df, meta, table)
    plant_col = meta[0][0]
    cur.execute(f"DELETE FROM `{table}` WHERE `{plant_col}` IN (%s)" % ",".join(["%s"] * len({r[0] for r in rows})),
                list({r[0] for r in rows}))
    cols = ",".join(f"`{n}`" for n, _ in meta)
    ph = ",".join(["%s"] * len(meta))
    for i in range(0, len(rows), 2000):
        cur.executemany(f"INSERT INTO `{table}` ({cols}) VALUES ({ph})", rows[i:i + 2000])
    return len(rows)

def read_table(cur, table, plant):
    meta = table_columns(cur, table)
    cur.execute(f"SELECT * FROM `{table}` WHERE `{meta[0][0]}`=%s", (plant,))
    df = pd.DataFrame(cur.fetchall(), columns=TABLES[table])
    return df

def write_back(cur, table, df, plant):
    """Replace the plant's rows of `table` with an allocated dataframe (same column order)."""
    meta = table_columns(cur, table)
    cur.execute(f"DELETE FROM `{table}` WHERE `{meta[0][0]}`=%s", (plant,))
    rows, _ = prepare_rows(df[TABLES[table]].astype(object).where(df.notna(), None), meta, table)
    cols = ",".join(f"`{n}`" for n, _ in meta); ph = ",".join(["%s"] * len(meta))
    for i in range(0, len(rows), 2000):
        cur.executemany(f"INSERT INTO `{table}` ({cols}) VALUES ({ph})", rows[i:i + 2000])
