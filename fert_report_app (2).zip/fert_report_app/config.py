import os
DB = dict(host=os.getenv("DB_HOST", "localhost"), port=int(os.getenv("DB_PORT", 3306)),
          user=os.getenv("DB_USER", "root"), password=os.getenv("DB_PASSWORD", ""),
          database=os.getenv("DB_NAME", "fert_db"), charset="utf8mb4")
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "output")
# If a DB column is too narrow for the SAP data (e.g. decimal(5,2) for 0.011), widen it
# automatically instead of stopping with an error.
AUTO_WIDEN_COLUMNS = os.getenv("AUTO_WIDEN_COLUMNS", "0") == "1"
SECRET_KEY = os.getenv("SECRET_KEY", "change-me")
