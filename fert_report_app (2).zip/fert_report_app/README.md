# FERT report (Flask + PyMySQL)
1. `mysql < schema.sql` (your 3 tables, unchanged) then `mysql < schema_fix.sql` (3-decimal quantity columns) -- or set `AUTO_WIDEN_COLUMNS=1`.
2. `pip install -r requirements.txt`; set DB_HOST / DB_USER / DB_PASSWORD / DB_NAME env vars (config.py).
3. `python app.py` -> http://localhost:5000, upload ZPLAN, ZMB52, ZBOMEXPLODE, choose plant / shop (SH-3) / purchase group, download fert_report.xlsx.

Files: columns.py (positional column maps), db.py (load/read/write with type checks), engine.py (allocation), report.py (9 sheets), app.py, templates/index.html, lookups/*.csv (material-group & product descriptions taken from your fert_report.xlsx; not in the 3 SAP tables).
Allocation order: plan week, then priority, all shops together; stock is plant-wide. Results are written back into zplan (FG columns) and zmb_stock (assigned/balance).

## Allocation rules (engine.py)
1. **Order**: shop sequence (default ascending: SH-3, then SH-5 from the left-over; editable on the page) -> Plan month -> Plan week -> Priority (lower number = served first).
2. **Top-down (Zstock_allocation.docx)**: FERT stock first; then sub-assemblies level by level (FA, then GA, ...); then brought-out components.
   If FERT stock covers the plan, nothing below is required. If a FA is taken from stock, GA and everything below it is reduced by the covered share; if only GA is
   in stock, GA's components are reduced but components directly under FA are still required.
3. FG stock (FERT / ZFRT) is used only in the FG stage. Dependency-matrix rule is optional (off by default, see documentation).
Run `python tests/test_hierarchy.py` to see the document's AA101 scenarios (FA / GA / priority / month / shop order) pass.
