-- Your tables round SAP quantities that have 3 decimals (e.g. BOM qty 0.011 -> 0.01, 41.333 -> 41.33).
-- Run once (or set AUTO_WIDEN_COLUMNS=1 and the app does it). Table/column names and order are unchanged.
USE fert_db;
ALTER TABLE `zbomexplode` MODIFY `Bom_Qty` DECIMAL(18,4) DEFAULT NULL;
ALTER TABLE `zbomexplode` MODIFY `Total_Bom_Qty` DECIMAL(18,4) DEFAULT NULL;
ALTER TABLE `zbomexplode` MODIFY `SA_Qty` DECIMAL(18,4) DEFAULT NULL;
ALTER TABLE `zbomexplode` MODIFY `Total_Org_BomQty` DECIMAL(18,4) DEFAULT NULL;
ALTER TABLE `zmb_stock` MODIFY `Total_original_Stock_Qty` DECIMAL(18,4) DEFAULT NULL;
ALTER TABLE `zmb_stock` MODIFY `Balance_Stock_Qty` DECIMAL(18,4) DEFAULT NULL;
ALTER TABLE `zmb_stock` MODIFY `Assigned_Stock_Qty` DECIMAL(18,4) DEFAULT NULL;
