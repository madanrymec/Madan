"""Stock allocation engine (FG -> sub-assembly -> brought-out component), per Zstock_allocation.docx.

Order of allocation everywhere: Plan week ascending, then Priority ascending (all shops together,
because stock is a plant-wide pool); the report is filtered by shop afterwards.
"""
import numpy as np, pandas as pd

def num(s):
    return pd.to_numeric(s.astype(str).str.strip().replace({"": np.nan, "None": np.nan, "nan": np.nan, "NaT": np.nan}),
                         errors="coerce")

def s_(x):
    return "" if x is None or (isinstance(x, float) and np.isnan(x)) else str(x).strip()

# Allocation order: shop sequence first (stock is allocated shop by shop, e.g. SH-3 then SH-5 from the left-over),
# then Plan month, Plan week and Priority (earlier priority is served first).
ORDER = ["_shop", "plan_month", "plan_week"]
ALLOC_E_LEAF = True       # allocate in-house assemblies that have no sub-lines in the SA stage
BLOCK_FG_STOCK = True     # FG stock (FERT/ZFRT) is used only by the FG stage (document: "delete the FG stock from it_mb52_sa")
FG_TYPES = ("FERT", "ZFRT")

class Pools:
    """Stock pools keyed (material, sales_doc, item).  Plant stock = (material,'','')."""
    def __init__(self, stock):
        self.q, self.orig = {}, {}
        self.mtype = {s_(r.material): s_(r.material_type) for r in stock.itertuples(index=False)}
        self.blocked = set()
        for r in stock.itertuples(index=False):
            if s_(r.vendor_code): continue            # vendor stock is not plant stock
            so = s_(r.sales_doc); it = s_(r.item_sd) if so else ""
            k = (s_(r.material), so, it)
            v = float(r.total_orig_qty) if pd.notna(r.total_orig_qty) else 0.0
            self.q[k] = self.q.get(k, 0.0) + v
            self.orig[k] = self.orig.get(k, 0.0) + v
        self.stocked = {k[0] for k, v in self.orig.items() if v > 0}
    def key(self, mat, so="", it=""):
        so = s_(so)
        if so and (mat, so, s_(it)) in self.q: return (mat, so, s_(it))
        return (mat, "", "")
    def get(self, k): return self.q.get(k, 0.0)
    def block_fg(self):
        self.blocked = {m for m, t in self.mtype.items() if t in FG_TYPES}
    def take(self, k, want):
        if k[0] in self.blocked: return 0.0
        a = max(0.0, min(want, self.q.get(k, 0.0)))
        if k in self.q: self.q[k] -= a
        return a

def shop_rank(df_shop, order):
    return df_shop.map(lambda x: order.index(s_(x)) if s_(x) in order else len(order))

def allocate_fg(plan, pools, shop_order):
    plan = plan.copy()
    plan["_shop"] = shop_rank(plan["shop"], shop_order)
    for c in ["plan_qty", "mm_price", "plan_value"]: plan[c] = num(plan[c])
    plan["_pri"] = num(plan["priority"]).fillna(0).astype(int)
    plan["_ord"] = range(len(plan))
    order = plan.sort_values(ORDER + ["_pri", "_ord"]).index
    o, a, af, bal, val = {}, {}, {}, {}, {}
    for i in order:
        r = plan.loc[i]; k = pools.key(s_(r.material), r.sales_doc, r.item_sd)
        init = pools.get(k); q = r.plan_qty if pd.notna(r.plan_qty) else 0.0
        g = pools.take(k, q)
        o[i], a[i], af[i], bal[i] = init, g, init - g, q - g
        val[i] = g * (r.mm_price if pd.notna(r.mm_price) else 0.0)
    plan["orig_fg_stock"] = pd.Series(o); plan["assigned_fg_qty"] = pd.Series(a)
    plan["fg_stock_after"] = pd.Series(af); plan["balance_plan_qty"] = pd.Series(bal)
    plan["fg_assigned_value"] = pd.Series(val)
    return plan.drop(columns=["_pri", "_ord", "_shop"])

def allocate_bom(bom, plan_alloc, pools, shop_order, enforce_dependency=True):
    z = bom.copy()
    z["_shop"] = shop_rank(z["shop"], shop_order)
    for c in ["bom_qty", "plan_qty", "total_bom_qty", "total_org_qty", "total_org_val", "total_bom_val", "unit_price",
              "sa_qty", "latest_price", "min_lot", "reorder_point", "mm_price"]:
        z[c] = num(z[c])
    z["_pri"] = num(z["priority"]).fillna(0).astype(int)
    z["_ser"] = num(z["serial"]).fillna(0)
    z["_lvl"] = num(z["level"]).fillna(1).astype(int)
    z["_ord"] = range(len(z))
    for c in ["sales_doc", "item_sd"]: z[c] = z[c].map(s_)
    z["_grp"] = z["plan_week"].map(s_) + "|" + z["_pri"].astype(str) + "|" + z["fert"].map(s_) + "|" + z["sales_doc"] + "|" + z["item_sd"]
    z = z.sort_values(ORDER + ["_pri", "fert", "sales_doc", "item_sd", "_ser", "_ord"]).reset_index(drop=True)

    # FG balance ratio of each plan line (balance after FG stock / plan qty)
    p = plan_alloc.copy(); p["_pri"] = num(p["priority"]).fillna(0).astype(int)
    p["_ratio"] = np.where(p["plan_qty"] > 0, p["balance_plan_qty"] / p["plan_qty"], 1.0)
    rmap = p.drop_duplicates(["material", "plan_week", "_pri"]).set_index(["material", "plan_week", "_pri"])["_ratio"].to_dict()
    n = len(z)
    ratio = np.array([rmap.get((s_(f), s_(w), pr), 1.0) for f, w, pr in zip(z.fert, z.plan_week, z._pri)])

    # tree: parent = last row of level-1 inside the same plan line (rows are in explosion order)
    parent = np.full(n, -1); haschild = np.zeros(n, bool)
    grp = z["_grp"].values; lvl = z["_lvl"].values; last = {}; cur = None
    for i in range(n):
        if grp[i] != cur: cur, last = grp[i], {}
        if lvl[i] > 1 and (lvl[i] - 1) in last:
            parent[i] = last[lvl[i] - 1]; haschild[parent[i]] = True
        last[lvl[i]] = i

    comp = z["component"].map(s_).values; cp = z["comp_proc"].map(s_).values
    ph = z["phantom"].map(s_).values != ""; pp = z["parent_proc"].map(s_).values; pspl = z["parent_spl"].map(s_).values
    org = z["total_org_qty"].fillna(0).values
    R = np.zeros(n); A = np.zeros(n); fac = np.ones(n); excl = np.zeros(n, bool)
    node = {grp[i] + "|" + comp[i]: i for i in range(n) if haschild[i] and comp[i]}

    def depfrac(i):
        f = 1.0
        for c in (s_(z.at[i, "dep1"]), s_(z.at[i, "dep2"])):
            if not c or c not in pools.stocked: continue      # dependency only counts for SA codes that have stock
            j = node.get(grp[i] + "|" + c)
            if j is None: continue
            f = min(f, (A[j] / R[j]) if R[j] > 0 else 0.0)
        return f

    def parent_excluded(i):
        pi = parent[i]
        return (pp[i] == "F" and pspl[i] != "30") or (pi >= 0 and excl[pi])

    # ---- phase A: sub-assembly rows (rows that have children), parents before children
    sa_stage = haschild | ((cp == "E") & (comp != "")) if ALLOC_E_LEAF else haschild
    for i in np.where(sa_stage)[0]:
        pi = parent[i]; pf = 1.0 if pi < 0 else fac[pi]
        if ph[i]: fac[i] = pf; continue
        if parent_excluded(i): excl[i] = True; fac[i] = 0.0; continue
        Rv = org[i] * ratio[i] * pf; R[i] = Rv
        if cp[i] in ("F", "E") and comp[i] and Rv > 0:
            k = pools.key(comp[i], z.at[i, "sales_doc"], z.at[i, "item_sd"])
            A[i] = pools.take(k, Rv); fac[i] = pf * (Rv - A[i]) / Rv
        else:
            fac[i] = pf if Rv > 0 else 0.0
    # ---- phase B: brought-out leaf components (with dependency matrix check)
    for i in np.where(~sa_stage)[0]:
        pi = parent[i]; pf = 1.0 if pi < 0 else fac[pi]
        if ph[i]: continue
        if parent_excluded(i): excl[i] = True; continue
        if not comp[i]: continue
        Rv = org[i] * ratio[i] * pf; R[i] = Rv
        if cp[i] == "F" and Rv > 0:
            allowed = Rv * (depfrac(i) if enforce_dependency else 1.0)
            k = pools.key(comp[i], z.at[i, "sales_doc"], z.at[i, "item_sd"])
            A[i] = pools.take(k, allowed)
    z["req_after_fg_sa"] = R; z["assigned"] = A; z["excluded"] = excl; z["haschild"] = haschild
    z["parent_idx"] = parent; z["ratio"] = ratio
    z["shortage"] = np.where(R - A > 1e-9, R - A, 0.0)
    z["mrp_qty"] = np.where(z["shortage"] > 1e-9, R, 0.0)
    # SA required qty = required qty of the parent node (plan balance for first level)
    sa = []
    tb = z["total_bom_qty"].values
    for i in range(n):
        pi = parent[i]
        if pi < 0 or not np.isfinite(tb[pi]):
            q = (z.at[i, "sa_qty"] if pd.notna(z.at[i, "sa_qty"]) else 1.0) * (z.at[i, "plan_qty"] if pd.notna(z.at[i, "plan_qty"]) else 0)
        else:
            q = tb[pi]
        sa.append(q * ratio[i])
    z["sa_required"] = sa
    return z

def update_stock(stock, pools):
    """Write assigned / balance qty+value back into the ZMB52 dataframe (plant pool rows)."""
    s = stock.copy()
    for c in ["total_orig_qty", "total_orig_val"]: s[c] = num(s[c])
    asg, bal = [], []
    for r in s.itertuples(index=False):
        if s_(r.vendor_code): asg.append(0.0); bal.append(r.total_orig_qty); continue
        so = s_(r.sales_doc); k = (s_(r.material), so, s_(r.item_sd) if so else "")
        o = pools.orig.get(k, 0.0); rem = pools.q.get(k, 0.0)
        share = (r.total_orig_qty / o) if o else 0.0     # rows sharing a pool split it pro-rata
        asg.append((o - rem) * share); bal.append(rem * share)
    s["assigned_qty"] = asg; s["balance_qty"] = bal
    unit = np.where(s["total_orig_qty"] > 0, s["total_orig_val"] / s["total_orig_qty"], 0.0)
    s["assigned_val"] = s["assigned_qty"] * unit; s["balance_val"] = s["balance_qty"] * unit
    return s

def run(plan, stock, bom, enforce_dependency=True, shop_order=None):
    """shop_order: list of shops in allocation sequence (default: ascending shop code, e.g. SH-3 then SH-5)."""
    stock = stock.assign(total_orig_qty=num(stock["total_orig_qty"]))
    if not shop_order:
        shop_order = sorted({s_(x) for x in plan["shop"].dropna()} | {s_(x) for x in bom["shop"].dropna()} - {""})
    pools = Pools(stock)
    plan_a = allocate_fg(plan, pools, shop_order)
    if BLOCK_FG_STOCK: pools.block_fg()
    bom_a = allocate_bom(bom, plan_a, pools, shop_order, enforce_dependency)
    stock_a = update_stock(stock, pools)
    return plan_a, stock_a, bom_a
